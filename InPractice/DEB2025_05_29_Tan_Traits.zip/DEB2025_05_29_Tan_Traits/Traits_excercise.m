% Tan's excercise
% code by Starrlight Augustine

legend_mamm = {... % order matters!
    {'o', 8, 1, [0 0 0], [0 0 1]}, 'Mammalia'
    {'o', 8, 1, [0 0 0], [0.8 0.8 0.8]}, 'Animalia'
    };
   

%% primary scaling

shstat_options('default');
LiEHb = read_allStat({'L_i', 'E_Hb'});

[Li_EHb, leg] = shstat(LiEHb, legend_mamm, 'Mammalia');
figure(Li_EHb)
xlabel('_{10}log ult.struct.length, L_i^\infty, cm')
ylabel('_{10}log E_H^b, J')
print -r300 -dpng Li_EHb_mammalia.png
figure(leg)
print -r300 -dpng leg_Mammalia.png

lineage('Dasyurus_viverrinus') % in the presentation the species is Sarcophilus harrisii, but we have a different outlier now

%% secondary scaling
shstat_options('default')
LirBcT = read_allStat({'L_i', 'r_B', 'c_T'});
LirB = [LirBcT(:, 1), LirBcT(:,2)];
[Li_rB, leg] = shstat(LirB, legend_mamm, 'Mammalia');
figure(Li_rB)
xlabel('_{10}log ult.struct.length, L_i^\infty, cm')
ylabel('_{10}log rT_B, 1/d, T_typical') 
print -r300 -dpng Li_rB_mammalia.png
figure(leg)
print -r300 -dpng leg_Mammalia.png

LirB = [LirBcT(:, 1), LirBcT(:,2)./ LirBcT(:,3)];
[Li_rB, leg] = shstat(LirB, legend_mamm, 'Mammalia');
figure(Li_rB)
xlabel('_{10}log ult.struct.length, L_i^\infty, cm')
ylabel('_{10}log r_B, 1/d, T_ref')
print -r300 -dpng Li_rB_mammalia_Tref.png
figure(leg)



%% ecocodes
select_eco('ecozone', {'MS', 'TS'}) % selection of all (terrestrial and marine) Antarctic species
speciesNames = select_eco('ecozone', {'MS', 'TS'});
LiPM_antarctica = read_stat(speciesNames, {'L_i', 'p_M'});
plot(log10(LiPM_antarctica(:,1)), log10(LiPM_antarctica(:,2)), 'ro')
