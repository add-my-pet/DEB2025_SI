function [data, auxData, metaData, txtData, weights] = mydata_Daphnia_magna

%% set metaData
metaData.phylum     = 'Arthropoda'; 
metaData.class      = 'Branchiopoda'; 
metaData.order      = 'Anomopoda'; 
metaData.family     = 'Daphniidae';
metaData.species    = 'Daphnia_magna'; 
metaData.species_en = 'Waterflea'; 

metaData.ecoCode.climate = {'Cfa', 'Cfb', 'Dfa', 'Dfb', 'Dfc'};
metaData.ecoCode.ecozone = {'TH', 'TPa'};
metaData.ecoCode.habitat = {'0iFp', '0iFl', '0iFm'};
metaData.ecoCode.embryo  = {'Fbf'};
metaData.ecoCode.migrate = {};
metaData.ecoCode.food    = {'biPp', 'biD'};
metaData.ecoCode.gender  = {'D'};
metaData.ecoCode.reprod  = {'Apf'};

metaData.T_typical  = C2K(20); % K, body temp
metaData.data_0     = {'ab'; 'am'; 'Lb'; 'Lp'; 'Wd0'; 'Wdb'; 'Wd_L'}; 
metaData.data_1     = {'t-L_f'; 't-Wd_f'; 't-M_PLC'; 't-N_f'; 'L-JX';'L-Fm'; 'L-JO'; 't-S'; 'X-Jx'; 'T-ab'; 'T-ap'; 'L-Wd'}; 

metaData.COMPLETE = 6; % using criteria of LikaKear2011

metaData.author   = {'Bas Kooijman'};    
metaData.date_subm = [2009 04 08];              
metaData.email    = {'bas.kooijman@vu.nl'};            
metaData.address  = {'VU University Amsterdam'};   

metaData.author_mod_1   = {'Bas Kooijman'};    
metaData.date_mod_1 = [2012 01 04];              
metaData.email_mod_1    = {'bas.kooijman@vu.nl'};            
metaData.address_mod_1  = {'VU University Amsterdam'};   

metaData.author_mod_2   = {'Bas Kooijman'};    
metaData.date_mod_2 = [2016 01 27];              
metaData.email_mod_2    = {'bas.kooijman@vu.nl'};            
metaData.address_mod_2  = {'VU University Amsterdam'};   

metaData.author_mod_3   = {'Andre Gergs'};    
metaData.date_mod_3     = [2019 03 16];              
metaData.email_mod_3    = {'andre.gergs@bayer.com'};            
metaData.address_mod_3  = {'Bayer AG'}; 

metaData.author_mod_4   = {'Bas Kooijman'};    
metaData.date_mod_4     = [2023 03 29];              
metaData.email_mod_4    = {'bas.kooijman@vu.nl'};            
metaData.address_mod_4  = {'VU University, Amsterdam'};   

metaData.curator     = {'Starrlight Augustine'};
metaData.email_cur   = {'starrlight@tecnico.ulisboa.pt'}; 
metaData.date_acc    = [2023 03 29];

%% set data
% uni-variate data

%time since start experiment (d), body length (mm)
tLc = [ ... %concentrations 
0	1.05	1.03	1.03	1.03	1.01	1.04
5	2.38	2.44	2.02	2.19	1.96	2.35
9	3.43	3.35	2.76	2.88	2.95	2.65
14	3.82	3.97	3.37	3.48	3.52	3.21
21	3.98	4.22	3.69	3.66	3.62	3.38
];
t = tLc(:,1); % d, time
L = tLc(:,2:end)/10; % cm, length

for i = 1: (length(tLc(1,:))-1)
    tLc = ['tLc',num2str(i)];
    data.(tLc) = [t, L(:,i)]; % d, #
    units.(tLc)   = {'d', 'cm'};  label.(tLc) = {'time', 'body length'};  
    temp.(tLc)    = C2K(20);  units.temp.(tLc) = 'K'; label.temp.(tLc) = 'temperature';
    bibkey.(tLc) = 'MackSkjo2015';
    comment.(tLc) = 'data from low (regular) food experiment';
end


% time-reproduction
%time since start experiment (d), cumulative reproduction (#)
tNc = [ ... %concentrations 
0	0	    0	    0	    0	    0	0
7	0	    0	    0	    0	    0	0
8	4.9	    6.2	    0	    0	    0	0
9	9	    7.7	    4.6	    0.2	    0	0
10	10.1	13	    6.3	    3.3	    0	0
11	24.1	29	    6.3	    3.3	    0.5	0
12	25.6	29	    18.9	5	    0.5	0
13	28.3	37.9	22.8	13.5	0.5	0
14	44.6	54.2	22.8	15.8	1.5	0
15	48.6	54.2	32.9	19.7	1.5	0
16	48.6	62.9	41.6	26.7	1.5	0
17	52.8	80.2	41.6	28.2	1.5	0
18	65.6	83.2	47.3	30.3	1.5	0
19	67.8	92.7	53.8	32.8	1.5	0
20	74.6	109.7	57.6	37.4	1.5	0
21	85.2	109.7	60.1	38.4	1.5	0
];
t = tNc(:,1); % d, time
N = tNc(:,2:end); % #, cumulative numbers

for i = 1: (length(tNc(1,:))-1)
    tNc = ['tNc',num2str(i)];
    data.(tNc) = [t, N(:,i)]; % d, #
    units.(tNc)   = {'d', '#'};  label.(tNc) = {'time', 'cumulative neonates'};  
    temp.(tNc)    = C2K(20);  units.temp.(tNc) = 'K'; label.temp.(tNc) = 'temperature';
    bibkey.(tNc) = 'MackSkjo2015';
end



  
%% set weights for all real data
weights = setweights(data, []);
% weights.tLc2 = 5 * weights.tLc2;
% weights.tLc3 = 5 * weights.tLc3;
% weights.tLc4 = 5 * weights.tLc4;

for i = 1: (length(tLc(1,:))-1)
    tLc = ['tLc',num2str(i)];
    
    weights.(tLc) = 10 * weights.(tLc);
end

%% set pseudodata and respective weights
[data, units, label, weights] = addpseudodata(data, units, label, weights);
%weights.psd.k_J = 5 * weights.psd.k_J;

%% pack auxData and txtData for output
auxData.temp = temp;
txtData.units = units;
txtData.label = label;
txtData.bibkey = bibkey;
txtData.comment = comment;

%% Group plots
 set1 = {'tLc1','tLc2','tLc3','tLc4','tLc5','tLc6'}; subtitle1 = {'MackSkjo2015'};
  set2 = {'tNc1','tNc2','tNc3','tNc4','tNc5','tNc6'}; subtitle2 = {'MackSkjo2015'};
% 
 metaData.grp.sets = {set1, set2};
 metaData.grp.subtitle = {subtitle1, subtitle2};

%% Discussion points
D1 = 'Males are assumed to differ from females by {p_Am} and s_G only';
D2 = 'The survival data tS_f for females are assumed to have a background hazard rate of ';
D3 = 'mod_3: Female daphnids are assumed to change kappa in response to conditions of low food availability, for a detailed discussion see GergPreu2014';
D4 = 'mod_3: Daphnids are assumed to increase their filtration rate at prolonged conditons of low food availablity (see Lampert W. Limnol. Oceanogr., 39(5), 1994,997-1006)';
D5 = 'mod_3:Laboratory expariments with daphnids are frequently done using a constant amount of food added e.g. on a daily absis, while the ingestion rate increases as the daphnid grows. This experiemtnal design might result in limited food condition later in the experiments and is not accounted for by the assumption of a constant value for the scaled functional response.';
D6 = 'mod_4: males have equal state variables at b, compared to females';
metaData.discussion = struct('D1',D1, 'D2',D2, 'D3',D3, 'D4',D4, 'D5',D5, 'D6',D6);

%% Facts
F1 = 'This entry is discussed in Kooy2010';
metaData.bibkey.F1 = 'Kooy2010'; 
metaData.facts = struct('F1',F1);

%% Links
metaData.links.id_CoL = '6CCSV'; % Cat of Life
metaData.links.id_ITIS = '83884'; % ITIS
metaData.links.id_EoL = '46498265'; % Ency of Life
metaData.links.id_Wiki = 'Daphnia_magna'; % Wikipedia
metaData.links.id_ADW = 'Daphnia_magna'; % ADW
metaData.links.id_Taxo = '33105'; % Taxonomicon
metaData.links.id_WoRMS = '148372'; % WoRMS

%% References
bibkey = 'Wiki'; type = 'Misc'; bib = ...
'howpublished = {\url{http://en.wikipedia.org/wiki/Daphnia_magna}}';
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Kooy2010'; type = 'Book'; bib = [ ...  % used in setting of chemical parameters and pseudodata
'author = {Kooijman, S.A.L.M.}, ' ...
'year = {2010}, ' ...
'title  = {Dynamic Energy Budget theory for metabolic organisation}, ' ...
'publisher = {Cambridge Univ. Press, Cambridge}, ' ...
'pages = {Table 4.2 (page 150), 8.1 (page 300)}, ' ...
'howpublished = {\url{../../../bib/Kooy2010.html}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%

bibkey = 'MackSkjo2015'; type = 'Article'; bib = [ ... 
'doi = {10.1016/j.aquatox.2015.01.023 }, ' ...
'author = {Mackevica, A. and Skjolding, L.M. and Gergs, A. and Palmqvist, A. and Baun, A.}, ' ... 
'year = {2015}, ' ...
'title = {Chronic toxicity of silver nanoparticles to Daphnia magna underdifferent feeding conditions}, ' ...
'journal = {Aquatic Toxicology}, ' ...
'volume = {161}, ' ...
'pages = {10-16}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];

