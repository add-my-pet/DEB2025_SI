function [prdData, info] = predict_Daphnia_magna(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);
  
  % compute temperature correction factors
  TC = 1;% tempcorr(temp.ab, T_ref, T_A); kT_M = TC * k_M; % all data at T_ref
  
  % zero-variate data

  % life cycle
  pars_tp = [g k l_T v_Hb v_Hp];
  [t_p, t_b, l_p, l_b,  info] = get_tp(pars_tp, f);
  
  % initial
  pars_UE0 = [V_Hb; g; k_J; k_M; v]; % compose parameter vector
  U_E0 = initial_scaled_reserve(f, pars_UE0); % d.cm^2, initial scaled reserve

  % predict uni-variate data
   E_t0 = E_m * (L_0 * del_M)^3 ;% p_Am * (L_0 * del_M)^2 * 0.5; % J, initial reserve    
   LEHRD_0 = [L_0*del_M,  E_t0, E_Hb, 0, 0]; % pack initial conditions
   c = [0	10 20 30 40 50]; % concentrations [mg a.s./kg]
      
    t = tLc1(:,1); % time vectorfor length
    t2 = tNc1(:,1); % time vector for offspring
    
    for i = 1:length(c)  
        
        par_LEHR = [p_M, v, k_J, p_Am, kap, E_G, E_Hp, kap_R, f]; % pack parameters  
        par_LEHRD = [par_LEHR];
        
        %length
        tLc = ['tLc',num2str(i)];        
        [t, LEHRD] = ode45(@get_LEHRD, t, LEHRD_0, [], par_LEHRD);  
         L = LEHRD(:,1)/del_M; % cm, physical length   
         prdData.(tLc) = L; 
        
        %reproduciton
        tNc = ['tNc',num2str(i)];        
        [t2, LEHRD] = ode45(@get_LEHRD, t2, LEHRD_0, [], par_LEHRD);  
        N = LEHRD(:,4)/(U_E0 * p_Am);
        prdData.(tNc) = N;              
    end    
    
end

%% % SUBFUNCTION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dLEHRD] = get_LEHRD(t, LEHRD, par_LEHRD, f)
    %% function to calculate L, E, H, R , C and S dynamically over time
    % input parameters: 
    p_M     = par_LEHRD(1); % J/d.cm^3, vol-spec somatic maint
    v       = par_LEHRD(2); % cm/d, energy conductance
    k_J     = par_LEHRD(3); % 1/d, maturity maint rate coefficient
    p_Am    = par_LEHRD(4); % J / d.cm^2, surface-area specific maximum assimilation rate
    kap     = par_LEHRD(5); % -, allocation fraction to soma
    E_G     = par_LEHRD(6); % J/cm^3, spec cost for structure
    E_Hp    = par_LEHRD(7); % J, maturity at puberty
    kap_R   = par_LEHRD(8); % -, reproduction efficiency    
    f   = par_LEHRD(9); % -, reproduction efficiency  

    
% initialize output parameters
    L       = LEHRD(1); % cm, state 1 is the structural length at previous time point
    E       = LEHRD(2); % J, state 2 is the energy reserve
    H       = LEHRD(3); % J, state 3 is energy invested in maturity
    R       = LEHRD(4); % J, state 4 is the reproduction buffer
    D       = LEHRD(5); % �g/l, scaled damage
    
    
    %%
    % growth rate    
    r = ((E * v / L^4) - (p_M / kap)) / ((E / L^3) + (E_G / kap)); % 1/d, specific growth rate
    % fluxes
    pC = E * (v / L -  r);            % J/d, mobilization
    pA = f * p_Am * L^2;              % J/d, assimilation
    pJ = H * k_J;                     % J/d; energy invested in maturity  
    
    % calculate changes in state variables
    dL = L * r / 3;                   % cm/d growth     
    dE = pA - pC;                     % J/d reserve dynamics      
    dH = (H < E_Hp) * max(0, (1 - kap) * pC - pJ);          % J/d increase in maturation
    dR = (H >= E_Hp) * kap_R * max(0, (1 - kap) * pC - pJ); % J/d investment in reproduction
    dD = 0;

   %%
    dLEHRD = [dL; dE; dH; dR; dD]; % collect derivatives    
    
end

