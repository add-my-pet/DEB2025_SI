function [par, metaPar, txtPar] = pars_init_Daphnia_magna(metaData)

metaPar.model = 'std'; 

%% core primary parameters 
par.z = 0.1516;        free.z     = 0;       units.z = '-';          label.z = 'zoom factor for female'; 
par.F_m = 30.17;       free.F_m   = 0;      units.F_m = 'l/d.cm^2'; label.F_m = '{F_m}, max spec searching rate'; 
par.kap_X = 0.9;       free.kap_X = 0;      units.kap_X = '-';      label.kap_X = 'digestion efficiency of food to reserve'; 
par.kap_P = 0.05;      free.kap_P = 0;      units.kap_P = '-';      label.kap_P = 'faecation efficiency of food to faeces'; 
par.v = 0.1858;        free.v     = 0;      units.v = 'cm/d';       label.v = 'energy conductance'; 
par.kap = 0.5809;      free.kap   = 0;      units.kap = '-';        label.kap = 'allocation fraction to soma';
par.kap_R = 0.95;      free.kap_R = 0;      units.kap_R = '-';      label.kap_R = 'reproduction efficiency'; 
par.p_M = 1200;        free.p_M   = 0;      units.p_M = 'J/d.cm^3'; label.p_M = '[p_M], vol-spec somatic maint'; 
par.p_T = 0;           free.p_T   = 0;      units.p_T = 'J/d.cm^2'; label.p_T = '{p_T}, surf-spec somatic maint'; 
par.k_J = 0.2537;      free.k_J   = 0;      units.k_J = '1/d';      label.k_J = 'maturity maint rate coefficient';
par.E_G = 4400;        free.E_G   = 0;      units.E_G = 'J/cm^3';   label.E_G = '[E_G], spec cost for structure'; 
%AmP value: par.E_Hb = 0.05464;    free.E_Hb  = 1;      units.E_Hb = 'J';       label.E_Hb = 'maturity at birth'; 
par.E_Hb = 0.03859;    free.E_Hb  = 1;      units.E_Hb = 'J';       label.E_Hb = 'maturity at birth'; 
par.E_Hp = 1.09;       free.E_Hp  = 0;      units.E_Hp = 'J';       label.E_Hp = 'maturity at puberty';  
par.h_a = 0.0002794;   free.h_a   = 0;      units.h_a = '1/d^2';    label.h_a = 'Weibull aging acceleration'; 
par.s_G = -0.3;        free.s_G   = 0;      units.s_G = '-';        label.s_G = 'Gompertz stress coefficient for female'; 

%% other parameters 
par.T_A = 6400;        free.T_A   = 0;      units.T_A = 'K';        label.T_A = 'Arrhenius temperature'; 
par.T_ref = 293.15;    free.T_ref = 0;      units.T_ref = 'K';      label.T_ref = 'Reference temperature'; 
par.del_M = 0.264;     free.del_M = 0;      units.del_M = '-';      label.del_M = 'shape coefficient'; 
par.eR0 = 1;           free.eR0   = 0;      units.eR0 = '-';        label.eR0 = 'eR at start starvation '; 
par.f = 0.9;             free.f     = 0;      units.f = '-';          label.f = 'scaled functional response for 0-var data';

par.L_0 = 0.103;      free.L_0  = 0;      units.L_0  = 'd';      label.L_0  = 'MackSkjo2015 data';

%% set chemical parameters from Kooy2010 
[par, units, label, free] = addchem(par, units, label, free, metaData.phylum, metaData.class);
par.d_V = 0.19;     free.d_V   = 0;   units.d_V = 'g/cm^3';         label.d_V = 'specific density of structure';  % g/cm^3, specific density of structure, see ref bibkey
par.d_E = par.d_V;

%% Pack output: 
txtPar.units = units; txtPar.label = label; par.free = free; 
